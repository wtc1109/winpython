import os, time, sys
import ConfigParser
import json
import MySQLdb
import psutil, signal
import datetime
filename = __file__
path1 = os.getcwd()
env = os.environ
strt=time.asctime()
stat = os.stat("conf.conf")
cti = time.ctime(stat.st_mtime)
mti = datetime.date.fromtimestamp(stat.st_mtime).isoformat()

prog = 'python /home/w/PycharmProjects/linuxpython/multi_ucmq5.py &'
print len(prog)
sp1 = prog.split(' ')
print sp1[len(sp1)-1]
s = os.getcwd()
pids1 = psutil.pids()
for pid1 in pids1:
    p = psutil.Process(pid1)
    print "pid=%d, pname=%s"%(pid1, p.name())
    if "python" == p.name()[:6]:
        print "python"
        os.kill(pid1, signal.SIGKILL)
path = s[:s[0:s.rfind('/')].rfind('/')]

str1 = "%Y-%M-%D"
per=0
print len(str1)
print type(str1)
a1 = str1[len(str1)-1]
_dicR = {'R':80,'G':0, 'B':0, 'T':100}
_dicG = {'R':0,'G':80, 'B':0, 'T':100}
_dicB = {'R':0,'G':0, 'B':80, 'T':100, "te":"teest"}
_dic2 = {'T1':json.dumps(_dicR), 'T2':json.dumps(_dicG), 'T3':json.dumps(_dicB)}
rgb = json.dumps(_dic2)
_dic_rgb = json.loads(rgb)
a3 = sys._getframe().f_lineno
print "line:"+str(a3)
a2 = str(type(_dicB["te"]))
print a2
if not type(_dicB["R"])==int:
    print type(_dicB["R"])
print type(_dicB["R"])
while True:
    per += str1[per:].find('%')
    if per < 0:
       break
    per2 = str1[per+2:].find('%')
    print str1[per+1:per+2]
    if per2 < 0:
        print str1[per+2:]
    else:
        print str1[per+2:per+2+per2]
    per += 2
    if per >= len(str1):
        break
print env['HOME']
home = env['PWD']
pos = home.rfind("/")
root_dir = home[0:pos]
#os.mkdir("/home/bluecard/hvpdgi")
stat = os.stat("/tmp/")
cti = time.ctime(stat.st_ctime)
cf = ConfigParser.ConfigParser()
#cf.read(home + "/ucmq.ini")
cf.read("conf.conf")
secs = cf.sections()
opts = cf.options("ucmq")
print opts

#kvs = cf.items("ucmq")
#print kvs

str_val = cf.get("ucmq", "server_addr")
int_val = cf.getint("ucmq", "server_port")
print "str=", str_val
print "int=", int_val
cf.set("server", "http_listen_port", 8800)
cf.add_section("wtc")
cf.set("wtc", "mydb", "system")
cf.write(open(home+"/conf.conf","w"))