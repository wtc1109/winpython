import os
env = os.environ
print env["PWD"]