#!/bin/sh
python newdevice60.pyc
