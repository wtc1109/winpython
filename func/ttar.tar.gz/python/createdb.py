import MySQLdb
import time
print time.time(), time.clock()

try:
    conn = MySQLdb.connect(host="localhost", user="root", passwd="123456", db="AlgReturndb2")
    conn.autocommit(1)
    cur = conn.cursor()
except:
    conn = MySQLdb.connect(host="localhost", user="root", passwd="123456")
    conn.autocommit(1)
    cur = conn.cursor()
    cur.execute("create database AlgReturndb2")
    cur.execute("use AlgReturndb2")

try:
    cur.execute("create table AiSettingTable("
                "sn char(32) primary key, "             #0  A
                "ip char(32),"                          #1B
                "slave_flag int,"                       #2C
                "neighbor_sn char(32),"                 #3D
                "bluetooth_id char(16),"                #4E
                "user_set_space int, "                  #5F
                "installation_space int, "              #6G
                "valid_space_bitmap int, "              #7H
                "focal_length float,"                   #8I
                "LedCtrl_bitmap_sn char(64), "          #9J
                "LedCtrl_change_sn char(64), "          #10K
                "LedCtrl_Output_table char(64), "       #11L
                "LedCtrl_TwinkleQueue char(128), "      #12M
                "LedCtrl_Selected_auto_menu int, "                #13 N 0:AUTO, 1:menual
                "LedCtrl_Menual_Val_set char(32), "         #14 O
                "ParkingLine_auto_manual_flag int,"     #15 P
                "ParkingLine1_manual_setup char(64),"        #16 Q
                "ParkingLine2_manual_setup char(64),"        #17 R
                "ParkingLine3_manual_setup char(64),"        #18S
                "Menual_Set_ParkingLine_3confidence_coe char(8)"   #19 T
                ")")
except Exception, e:
    print "create table AiSettingTable",e
    pass
try:
    cur.execute("create table AiStatusTable("
                "sn char(32) primary key, "  # 0
                "AutoLedStatus char(16),"  # 1
                "CurLedStatus char(16)"  # 2


                ")engine=memory")  # 17
except Exception, e:
    print "create table AiStatusTable", e
    pass

try:
    cur.execute("insert into AiSettingTable (sn, ip, slave_flag, user_set_space, installation_space, valid_space_bitmap,"
                "LedCtrl_Selected_auto_menu, ParkingLine_auto_manual_flag) values('123456788', "
                "'192.168.7.211', 0, 3, 3, 7, 0, 0)")
    cur.execute("insert into AiSettingTable (sn, ip, slave_flag, user_set_space, installation_space, valid_space_bitmap,"
                "LedCtrl_Selected_auto_menu, ParkingLine_auto_manual_flag) values('123456789', "
                "'192.168.7.211', 0, 3, 3, 7, 0, 0)")
    cur.execute("insert into AiSettingTable (sn, ip, slave_flag, user_set_space, installation_space, valid_space_bitmap,"
                "LedCtrl_Selected_auto_menu, ParkingLine_auto_manual_flag) values('123456790', "
                "'192.168.7.169', 0, 3, 3, 7, 0, 0)")
    cur.execute("insert into AiSettingTable (sn, ip, slave_flag, user_set_space, installation_space, valid_space_bitmap,"
                "LedCtrl_Selected_auto_menu, ParkingLine_auto_manual_flag, ParkingLine1_manual_setup, "
                "ParkingLine2_manual_setup,"
                "ParkingLine3_manual_setup"
                ") values('123456791', '192.168.7.169', 0, 3, 3, 7, 0, 1, '10:10,30:10,10:80,30:80', "
                "'35:10,35:80,55:10,55:80',"
                "'60:10,60:80,80:10,80:80')")
    cur.execute("insert into AiSettingTable (sn, ip, slave_flag, user_set_space, installation_space, "
                "valid_space_bitmap,"
                "LedCtrl_Selected_auto_menu, ParkingLine_auto_manual_flag, ParkingLine1_manual_setup, "
                "ParkingLine2_manual_setup,"
                "ParkingLine3_manual_setup"
                ") values('123456792', '192.168.7.169', 0, 3, 3, 7, 0, 1,'10:10,30:10,10:80,30:80', "
                "'35:10,35:80,55:10,55:80',"
                "'60:10,60:80,80:10,80:80')")
    cur.execute("insert into AiSettingTable (sn, ip, slave_flag, user_set_space, installation_space, "
                "valid_space_bitmap,"
                "LedCtrl_Selected_auto_menu, ParkingLine_auto_manual_flag, ParkingLine1_manual_setup,"
                " ParkingLine2_manual_setup,"
                "ParkingLine3_manual_setup"
                ") values('123456793', '192.168.7.169', 0, 3, 3, 7, 0, 1,'10:10,30:10,10:80,30:80', '35:10,35:80,55:10,55:80',"
                "'60:10,60:80,80:10,80:80')")
except Exception, e:
    print("insert AiSettingTable error ",e)
    pass
aa = cur.execute("select * from AiSettingTable")
if 0 != aa:
    allinfo = cur.fetchmany(aa)
    for a1 in allinfo:

        sn = a1[0]
        update_info = "update AiSettingTable set LedCtrl_bitmap_sn = " + sn + " where sn = " + sn
        cur.execute(update_info)
try:
    cur.execute("create table AIret_vals("
                "sn char(32) primary key, "             #0A
                "latest_ctrl DATETIME,"                 #1B
                "ai_out_space int,"                     #2C
                "ai_out_space_bitmap char(8),"          #3D
                "ai_out_parkingline1_pos char(32),"     #4E
                "ai_out_parkingline2_pos char(32),"     #5F
                "ai_out_parkingline3_pos char(32),"     #6G
                "ai_out_Car1_pos char(32),"             #7H
                "ai_out_Car2_pos char(32),"             #8I
                "ai_out_Car3_pos char(32),"             #9J
                "ai_out_every_car_pos1 char(32),"         #10K
                "ai_out_every_car_pos2 char(32),"        #11L
                "ai_out_every_car_pos3 char(32),"        #12M
                "ai_out_3confidence_coe char(8),"       #13N
                "Pic_type_for char(16),"                #14 O
                "Pic_sn char(16),"                      #15     P
                "Pic_definition char(16),"              #16     Q
                "resent_Pic_path_name char(64),"             #17 R 
                "Cross_parking_alarm char(16),"         #18 S
                "Other_alarm char(16)"                 #19 T
                ")engine=memory")
except Exception, e:
    print "create table AIret_vals",e
    pass
for a1 in allinfo:
    sn = a1[0]
    update_info = "insert into AIret_vals (sn, ai_out_space_bitmap) values(" + sn + ", 'xox')"
    try:
        cur.execute(update_info)
    except Exception, e:
        print "insert into AIret_vals",e
        pass
try:
    cur.execute("create table AIChangeMQ("
                "id int not null auto_increment primary key,"
                "sn char(32),"
                "info char(32),"
                "user char(32),"
                "addition1 char(64),"
                "addition2 char(64),"
                "addition3 char(64),"
                "addition4 char(64),"
                "msg_time DATETIME"

                ")engine=memory")
except Exception, e:
    print "create table AIChangeMQ", e
    pass

for a1 in allinfo:
    sn = a1[0]
    update_info = "insert into AIChangeMQ(sn, info, user, msg_time) values ('" + sn + "', 'LAMP', 'ai', now())"
    update_info2 = "insert into AIChangeMQ(sn, info, user, addition1, msg_time) values ('" + sn + "', 'REPHOTO', 'ai', 'place', now())"
    update_info3 = "insert into AIChangeMQ(sn, info, user, addition1, addition2, addition3,msg_time) " \
                   "values ('" + sn + "', 'PARKINGLINE', 'ai', '10:10,30:10,10:85,30:85', '35:10,35:80,55:10,55:85'," \
                                      "'60:10,60:85,85:10,85:85', now())"
    update_info4 = "insert into AIChangeMQ(sn, info, user, addition1, addition2, msg_time) values ('" + sn + \
                   "', 'PLACE', 'ai', '2', 'xox', now())"
    update_info5 = "insert into AIChangeMQ(sn, info, user, addition1, msg_time) values ('" + sn + \
                   "', 'UPGRADE', 'ai', '/tmp/123.zip',  now())"
    try:
        cur.execute(update_info)
        cur.execute(update_info2)
        cur.execute(update_info3)
        cur.execute(update_info4)
        cur.execute(update_info5)
    except Exception, e:
        print "insert into AIChangeMQ", e
        pass

try:
    cur.execute("create table defaultXspace(id int not null auto_increment primary key, "
                "Flag_used char(8), output char(32))engine=memory")
except Exception, e:
    print e
    pass
try:
    cur.execute("create table defaultForGirls(id int not null auto_increment primary key, "
                "Flag_used char(8), output char(32))engine=memory")
except:
    pass
try:
    cur.execute("create table default3Lamp(id int not null auto_increment primary key, "
                "Flag_used char(8), output char(32))engine=memory")
except:
    pass
led_green = 'R:0,G:80,B:0,T:0'
led_red = 'R:80,G:0,B:0,T:0'
led_pink = 'R80,G40,B:40,T:0'

dic1 = {0:'o', 1:'x'}
dic2 = {0:'oo', 1:'ox', 2:'xo', 3:'xx'}
dic3 = {0:'ooo',1:'oox', 2:'oxo', 3:'oxx',4:'xoo', 5:'xox', 6:'xxo', 7:'xxx'}
dic4 = {0:'oooo',1:'ooox', 2:'ooxo', 3:'ooxx',4:'oxoo', 5:'oxox', 6:'oxxo', 7:'oxxx',
        8: 'xooo', 9: 'xoox',10 : 'xoxo', 11: 'xoxx', 12: 'xxoo', 13: 'xxox', 14: 'xxxo', 15: 'xxxx'}
dic5 = {0: 'ooooo', 1: 'oooox', 2: 'oooxo', 3: 'oooxx', 4: 'ooxoo', 5: 'ooxox', 6: 'ooxxo', 7: 'ooxxx',
        8: 'oxooo', 9: 'oxoox', 10: 'oxoxo', 11: 'oxoxx', 12: 'oxxoo', 13: 'oxxox', 14: 'oxxxo', 15: 'oxxxx',
        16: 'xoooo', 17: 'xooox', 18: 'xooxo', 19: 'xooxx', 20: 'xoxoo', 21: 'xoxox', 22: 'xoxxo', 23: 'xoxxx',
        24: 'xxooo', 25: 'xxoox', 26: 'xxoxo', 27: 'xxoxx', 28: 'xxxoo', 29: 'xxxox', 30: 'xxxxo', 31: 'xxxxx'
        }
dic6 = {0: 'oooooo', 1: 'ooooox', 2: 'ooooxo', 3: 'ooooxx', 4: 'oooxoo', 5: 'oooxox', 6: 'oooxxo', 7: 'oooxxx',
        8: 'ooxooo', 9: 'ooxoox', 10: 'ooxoxo', 11: 'ooxoxx', 12: 'ooxxoo', 13: 'ooxxox', 14: 'ooxxxo', 15: 'ooxxxx',
        16: 'oxoooo', 17: 'oxooox', 18: 'oxooxo', 19: 'oxooxx', 20: 'oxoxoo', 21: 'oxoxox', 22: 'oxoxxo', 23: 'oxoxxx',
        24: 'oxxooo', 25: 'oxxoox', 26: 'oxxoxo', 27: 'oxxoxx', 28: 'oxxxoo', 29: 'oxxxox', 30: 'oxxxxo', 31: 'oxxxxx',
        32: 'xooooo', 33: 'xoooox', 34: 'xoooxo', 35: 'xoooxx', 36: 'xooxoo', 37: 'xooxox', 38: 'xooxxo', 39: 'xooxxx',
        40: 'xoxooo', 41: 'xoxoox', 42: 'xoxoxo', 43: 'xoxoxx', 44: 'xoxxoo', 45: 'xoxxox', 46: 'xoxxxo', 47: 'xoxxxx',
        48: 'xxoooo', 49: 'xxooox', 50: 'xxooxo', 51: 'xxooxx', 52: 'xxoxoo', 53: 'xxoxox', 54: 'xxoxxo', 55: 'xxoxxx',
        56: 'xxxooo', 57: 'xxxoox', 58: 'xxxoxo', 59: 'xxxoxx', 60: 'xxxxoo', 61: 'xxxxox', 62: 'xxxxxo', 63: 'xxxxxx'
        }
lampX = {0:'R:100, G:100, B:100,T:0',1:'R:100, G:100, B:0,T:0',
         2:'R:100, G:0, B:100,T:0', 3:'R:100, G:0, B:0,T:0',
         4: 'R:0, G:100, B:100,T:0', 5: 'R:0, G:100, B:0,T:0',
         6: 'R:0, G:0, B:100,T:0', 7: 'R:0, G:0, B:0,T:0'}

dicX = []
dicX.append(dic1)
dicX.append(dic2)
dicX.append(dic3)
dicX.append(dic4)
dicX.append(dic5)
dicX.append(dic6)
print time.time(), time.clock()
if 0 == cur.execute("select * from defaultXspace"):
    for cnt in range(6):
        for i in range(len(dicX[cnt])-1):
            sql_str = "insert into defaultXspace(Flag_used, output) values('%s', '%s')" % (dicX[cnt][i], led_green)
            cur.execute(sql_str)
            sql_str = "insert into defaultForGirls(Flag_used, output) values('%s', '%s')" % (dicX[cnt][i], led_pink)
            cur.execute(sql_str)
        sql_str = "insert into defaultXspace(Flag_used, output) values('%s', '%s')" % (dicX[cnt][len(dicX[cnt])-1], led_red)
        cur.execute(sql_str)
        sql_str = "insert into defaultForGirls(Flag_used, output) values('%s', '%s')" % (dicX[cnt][len(dicX[cnt])-1], led_red)
        cur.execute(sql_str)
    for cnt in range(3):
        for i in range(len(dicX[cnt])):
            sql_str = "insert into default3Lamp(Flag_used, output) values('%s', '%s')" % (dicX[cnt][i], lampX[i])
            cur.execute(sql_str)
else:
    print "no need to insert into defaultXspace"
print time.time(), time.clock()