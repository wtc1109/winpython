import os
import ConfigParser
env = os.environ
print env['HOME']
home = env['HOME']
cf = ConfigParser.ConfigParser()
cf.read(home + "/ucmq.ini")
secs = cf.sections()
opts = cf.options("server")
print opts

kvs = cf.items("server")
print kvs

str_val = cf.get("server", "http_listen_addr")
int_val = cf.getint("server", "http_listen_port")
print "str=", str_val
print "int=", int_val
cf.set("server", "http_listen_port", 8800)
cf.add_section("wtc")
cf.set("wtc", "mydb", "system")
cf.write(open(home+"/conf.conf","w"))