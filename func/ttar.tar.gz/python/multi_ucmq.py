import urllib, urllib2, time, json
import os
import pika
import MySQLdb
import Queue
import threading
import logging
from logging.handlers import RotatingFileHandler

"""receive ucmq messages and download the files to local
"""
DIRECTION_SAVE_FILES = os.environ['HOME'] + "/hvcd/"
THREAD_NUM = 10 #how many threads

gQueues = []
gThread_using_flag = []
global mylogger
for i in range(THREAD_NUM):
    Info_queue = Queue.Queue(maxsize=5)
    gQueues.append(Info_queue)
gQueue_ret = Queue.Queue(maxsize=20)

test_data = {'name': 'testmq', 'opt':'get', 'ver':'2'}
test_data_encode = urllib.urlencode(test_data)
requrl = "http://192.168.7.19:8803/"
ucmq_url = requrl + '?' + test_data_encode
DB_name = "AlgReturndb2"
DB_host = "localhost"
DB_user = "root"
DB_passwd = "123456"

RabbitMQ_exchange = "amp.direct"
RabbitMQ_user = "guest"
RabbitMQ_passwd = "guest"
RabbitMQ_RouterKey = "test queue"


def create_logging(filename):
    Rthandler = RotatingFileHandler(filename, maxBytes=2048, backupCount=5)
    Rthandler.setLevel(logging.INFO)  #write files info
    formatter = logging.Formatter('%(asctime)s [Line=%(lineno)s] %(levelname)s %(message)s')
    Rthandler.setFormatter(formatter)
    logging.basicConfig(level=logging.NOTSET)       #write to stdio all
    logger = logging.getLogger(filename)
    logger.addHandler(Rthandler)
    return logger

def check_parser_ucmq_cmd(jstr):
    return 0, "abc"

def check_download_filename(jstr):
    global mylogger
    _dic1 = json.loads(jstr)
    try:
        _ip = _dic1["ip"]
    except:
        return 0, "ip"
    try:
        _location = _dic1["location"]
    except:
        return 0, "location"
    try:
        _pic_type = _dic1["type_for"]
    except:
        return 0, "type_for"
    try:
        _pic_sn = _dic1["pic_sn"]
    except:
        return 0, "pic_sn"
    try:
        _why = _dic1["why"]
    except:
        return 0, "why"
    try:
        _sn = _dic1["sn"]
    except:
        return 0, "sn"


    _path = DIRECTION_SAVE_FILES + _dic1["sn"]
    if not os.path.isdir(_path):
        try:
            os.mkdir(_path)
        except Exception, e:
            if not os.path.isdir(_path):
                mylogger.error(_path+str(e))
                return 0, str(e)

    _localtime1 = time.localtime()
    days = "%s%s" % (str(_localtime1.tm_mon).zfill(2), str(_localtime1.tm_mday).zfill(2))
    _path += '/' + days + '/'
    if not os.path.isdir(_path):
        try:
            os.mkdir(_path)
        except Exception, e:
            if not os.path.isdir(_path):
                mylogger.error(_path+str(e))
                return 0, str(e)

    return 1, _path




def ucmq_get_msg():
    global ucmq_url, mylogger
    while True:
        while True:
            try:
                res_data = urllib2.urlopen(ucmq_url)
                break
            except urllib2.URLError, e:
                print e
                mylogger.info(str(e))
                time.sleep(20)
                continue
        res = res_data.read()
        mq_str = res.split('\n')
        #print mq_str[0]
        ret_str = mq_str[0].rstrip('\r')
        if (ret_str != "UCMQ_HTTP_OK"):
            mq_str[1] = None
        res_data.close()
        break

    urllib.urlcleanup()
    return mq_str[1]

class DownloadThread(threading.Thread):
    def __init__(self, idnum):
        self.__id = idnum
        self.__url_addr = []
        self.__file_name = []
        self.__pic_type = []
        self.__logger = create_logging('thread%d.log'%idnum)
        threading.Thread.__init__(self)
    def run(self):
        global gQueues, gQueue_ret
        """
        {"slave": 0, "exp": "12365", "type_for": "place", 
        "ip": "192.168.7.185", "gain": "12.5", "pic_sn": "963185",
         "why": "auto", "definition": "500", "location": "/info/111.jpg", 
         "bluetooch_id": "654321", "neighbor": "123456788", _url = "http://" + _dic1["ip"] + _dic1["location"]
         "sn": "123456787"}"""
        while True:
            _recv_json = gQueues[self.__id].get(block=True)
            _recv_dict = json.loads(_recv_json)
            self.__url_addr = "http://" + _recv_dict["ip"] + _recv_dict["location"]
            self.__file_name = _recv_dict["path"] +  _recv_dict["pic_sn"] +".jpg"
            #print "Child id=" + str(self.__id)+ str(time.time()) +"get url=" + str(self.__url_addr) +" save to " + str(self.__file_name)
            step = 1
            try:
                fd, info = urllib.urlretrieve(url=self.__url_addr, filename= self.__file_name)
            except Exception, e:
                step = -1
                ret_str = str(e)
                self.__logger.warning(str(e)+self.__url_addr)
            finally:
                if step > 0:
                    try:
                        length = info.dict["content-length"]  # if length is 0,so remove the empty file
                    except KeyError:
                        os.remove(self.__file_name)
                        self.__logger.warning("download " + self.__file_name +"failed")
                    _ret_dic = {"ret":1, "id": self.__id, "file":self.__file_name}

            #        gQueue_ret.put(json.dumps({"ret": 1, "id": self.__id, "filename":self.__file_name, "pic_type":_recv_dict["pic_type"]}))
                else:
                    _ret_dic = {"ret":ret_str, "id": self.__id}
            #        gQueue_ret.put(json.dumps({"ret": ret_str, "id": self.__id}))
                _recv_dict.update(_ret_dic)
                gQueue_ret.put(json.dumps(_recv_dict))
                #print "child end  id=" + str(self.__id) +" time="+ str(time.time())
                self.__logger.debug("child end  id=" + str(self.__id) +" time="+ str(time.time()))


def get_a_rabbitmq_channel():
    credentials = pika.PlainCredentials(RabbitMQ_user, RabbitMQ_passwd)
    conn_params = pika.ConnectionParameters(host="localhost", port=5672, credentials=credentials)
    # conn_params = pika.ConnectionParameters(host= "192.168.7.19",port=5672, credentials=credentials)
    conn_broker = pika.BlockingConnection(conn_params)
    channel = conn_broker.channel()
    channel.exchange_declare(exchange=RabbitMQ_exchange, exchange_type="direct",
                             passive=False, durable=True, auto_delete=False)
    return channel


def get_a_sql_cur():
    global DB_name, DB_host, DB_user, DB_passwd, mylogger
    while True:
        try:
            conn = MySQLdb.connect(host=DB_host, user=DB_user, passwd=DB_passwd, db=DB_name)
            conn.autocommit(1)
            cur = conn.cursor()
            break
        except:
            time.sleep(20)
            mylogger.warn("Can't connect to MySQL")

    return cur

def maybe_add_a_new_device(json_str, cur):
    _dic1 = json.loads(json_str)
    try:
        _ip = _dic1["ip"]
    except:
        return
    try:
        _slave_flag = _dic1["slave"]
    except:
        return

    try:
        _neighbor = _dic1["neighbor"]
    except:
        _neighbor = ''
        pass
    try:
        _bluetooch = _dic1["bluetooch_id"]
    except:
        _bluetooch = ''
        pass
    a1 = cur.execute("select * from AiSettingTable where sn='"+_dic1["sn"]+"'")
    if 0 == a1:
        str_info = "insert into AiSettingTable (sn, ip, slave_flag, neighbor_sn, bluetooth_id, user_set_space," \
                   "installation_space, valid_space_bitmap, LedCtrl_bitmap_sn," \
                   "LedCtrl_Selected_auto_menu, ParkingLine_auto_manual_flag) values" \
                   "('%s', '%s', %d, '%s', '%s', 3, 3, 7, '%s', " \
                   % (_dic1["sn"], _ip, _slave_flag, _neighbor, _bluetooch, _dic1["sn"]) + ", 0, 0)"
        cur.execute(str_info)
    else:
        a1info = cur.fetchmany(a1)
        if (_ip != a1info[0][1]) or (_slave_flag != a1info[0][2]):
            str_info = "update AiSettingTable set ip='%s', slave_flag=%d"%(_ip, _slave_flag)
            if '' != _neighbor:
                str_info += ", neighbor_sn='%s'"%_neighbor
            if '' != _bluetooch:
                str_info += ", bluetooth_id='%s'"%_bluetooch
            str_info += " where sn='%s'"%_dic1["sn"]
            cur.execute(str_info)

    a1 = cur.execute("select * from AiSettingTable where sn='" + _dic1["sn"] + "'")
    return cur.fetchmany(a1)[0]

def HDCD_ucmq_cmd_process(jstr):
    return

def make_rabbitmq_msg(json_str, filename, sql):
    _dic = json.loads(json_str)
    try:
        why = _dic["why"]
        info = {"cam_id":_dic["sn"],"pic_full_name":filename,
                "slot_count":sql[5], "is_manual":sql[13],
                "slot_region1":sql[16],"slot_region2":sql[17],
                "slot_region3": sql[18],
                "slot_install":sql[6],
                "slot_bitmap":sql[7], "Pic_type_for":_dic["why"]}
    except:
        info = {"cam_id": _dic["sn"], "pic_full_name": filename,
                "slot_count": sql[5], "is_manual": sql[13],
                "slot_region1": sql[16], "slot_region2": sql[17],
                "slot_region3": sql[18],
                "slot_install": sql[6],
                "slot_bitmap": sql[7]}

    return info

if __name__ == '__main__':
    global mylogger
    mylogger = create_logging("Mthread.log")
    mylogger.info("start running")
    if not os.path.isdir(DIRECTION_SAVE_FILES):
        try:
            os.mkdir(DIRECTION_SAVE_FILES)
        except Exception, e:
            print e
            mylogger.error(str(e))
            os._exit()

    msg_props = pika.BasicProperties()
    msg_props.content_type = "text/plain"
    j = 600
    channel = get_a_rabbitmq_channel()
    cur = get_a_sql_cur()
    print time.time()
    threads = []
    thread_idles = THREAD_NUM

    for i in range(THREAD_NUM):
        flag = 1
        gThread_using_flag.append(flag)
        thread = DownloadThread(i)
        thread.start()
        threads.append(thread)
    _queue_block = False
    sleep_sec = 0.5
    ret_val = 0
    sec_start = time.time()
    while j > 0:
        json_str = None
        if thread_idles >= THREAD_NUM:
            thread_idles = THREAD_NUM#all thread is idle
            while True:
                json_str = ucmq_get_msg()
                if None != json_str:
                    break
                else:
                    time.sleep(0.5)
            sleep_sec = 0.02
            _queue_block = False
        elif 0 == thread_idles:   #all thread is busy
            _queue_block = True     #queue get block,until a thread is idle
        else:       #some thread is idle
            _queue_block = False
            json_str = ucmq_get_msg()
            #sleep_sec = (THREAD_NUM - thread_idles)/(2.0*THREAD_NUM)
        #print "thread_idle = %d"%thread_idles
        mylogger.warn("thread_idle = %d"%thread_idles)
        if None != json_str:
            sql_info = maybe_add_a_new_device(json_str, cur)
            ret_val = check_download_filename(json_str)
            if 1 == ret_val[0]:
                _dic = json.loads(json_str)
                _dic1 = {"path":ret_val[1]}
                _dic.update(_dic1)
                for i in range(THREAD_NUM):
                    if gThread_using_flag[i] == 1:
                        gQueues[i].put_nowait(json.dumps(_dic))
                        gThread_using_flag[i] = 0
                        #print "Queue put to id%d"%i
                        mylogger.debug("Queue put to id%d"%i)
                        break
                thread_idles -= 1
            ret_val = check_parser_ucmq_cmd(json_str)
            if 1 == ret_val[0]:
                HDCD_ucmq_cmd_process(json_str)

        rec_json_buff = []
        if True == _queue_block:
            try:
                #print "Queue get blocked"
                rec_json = gQueue_ret.get(block=True)
                gThread_using_flag[json.loads(rec_json)["id"]] = 1
                rec_json_buff.append(rec_json)
                thread_idles += 1
                #print "Queue get blocked"
                mylogger.debug("Queue get blocked")
            except IOError, Queue.Empty:
                pass
        else:
            Cur_qsize = gQueue_ret.qsize()
            #print "Queue get %d mq"%Cur_qsize
            mylogger.debug("Queue get %d mq"%Cur_qsize)
            for i in range(Cur_qsize):
                try:
                    rec_json = gQueue_ret.get(block=False)
                    gThread_using_flag[json.loads(rec_json)["id"]] = 1
                    thread_idles += 1
                    rec_json_buff.append(rec_json)

                    #print "Queue get " + rec_json
                    mylogger.debug("Queue get " + rec_json)
                except IOError, Queue.Empty:
                    pass

        for rec_json in rec_json_buff:
            dic1 = json.loads(rec_json)
            try:
                ret_val = dic1["ret"]
            except:
                continue
            if 1 != ret_val:
                continue
            try:
                _filename = dic1["file"]
            except:
                continue
            try:
                _pic_type = dic1["pic_type"]
            except:
                continue
            if "place" == _pic_type:
                msg = make_rabbitmq_msg(json_str, _filename, sql_info)
                js_msg = json.dumps(msg)
                channel.basic_publish(body=js_msg, exchange=RabbitMQ_exchange, properties=msg_props,
                                      routing_key=RabbitMQ_RouterKey)
            elif "plate" == _pic_type:
                msg = make_rabbitmq_msg(json_str, _filename, sql_info)
                js_msg = json.dumps(msg)
                channel.basic_publish(body=js_msg, exchange=RabbitMQ_exchange, properties=msg_props,
                                      routing_key=RabbitMQ_RouterKey)
        time.sleep(sleep_sec)
        #print "sleep ",sleep_sec
        mylogger.debug("sleep %f"%sleep_sec)

        j -= 1
    print "exit ",time.time(), "start @", sec_start
    exit()