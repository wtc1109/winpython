import socket
import json
import time
import fcntl
import struct
import uuid

RECEIVE_PORT = '10001'
UDP_BROADCAST_PORT = 9981

def Udp_broadcast(msg, port):

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    addr1 = ("255.255.255.255", port)
    #sock.bind(addr1)
    try:
        sock.sendto(json.dumps(msg), addr1)
    except Exception, e:
        print e


def get_ip_addr(ifname):
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    addr = socket.inet_ntoa(fcntl.ioctl(s.fileno(), \
                                        0x8915, \
                                        struct.pack('256s', ifname[:15]))[20:24])
    return addr

if __name__ == '__main__':
    addr = get_ip_addr("eth0")

    while True:
        struct_time = time.localtime()
        time_str = '%d-%02d-%02d %02d:%02d:%02d' % (struct_time.tm_year, struct_time.tm_mon, struct_time.tm_mday,
                                                    struct_time.tm_hour, struct_time.tm_min, struct_time.tm_sec)
        msg = {"AISERVERIP": addr, "port": RECEIVE_PORT, "timenow": time_str}
        Udp_broadcast(msg, UDP_BROADCAST_PORT)
        time.sleep(10)

