dic1 = {0:'o', 1:'x'}
dic2 = {0:'oo', 1:'ox', 2:'xo', 3:'xx'}
dic3 = {0:'ooo',1:'oox', 2:'oxo', 3:'oxx',4:'xoo', 5:'xox', 6:'xxo', 7:'xxx'}
dic4 = {0:'oooo',1:'ooox', 2:'ooxo', 3:'ooxx',4:'oxoo', 5:'oxox', 6:'oxxo', 7:'oxxx',
        8: 'xooo', 9: 'xoox',10 : 'xoxo', 11: 'xoxx', 12: 'xxoo', 13: 'xxox', 14: 'xxxo', 15: 'xxxx'}
dic5 = {0: 'ooooo', 1: 'oooox', 2: 'oooxo', 3: 'oooxx', 4: 'ooxoo', 5: 'ooxox', 6: 'ooxxo', 7: 'ooxxx',
        8: 'oxooo', 9: 'oxoox', 10: 'oxoxo', 11: 'oxoxx', 12: 'oxxoo', 13: 'oxxox', 14: 'oxxxo', 15: 'oxxxx',
        16: 'xoooo', 17: 'xooox', 18: 'xooxo', 19: 'xooxx', 20: 'xoxoo', 21: 'xoxox', 22: 'xoxxo', 23: 'xoxxx',
        24: 'xxooo', 25: 'xxoox', 26: 'xxoxo', 27: 'xxoxx', 28: 'xxxoo', 29: 'xxxox', 30: 'xxxxo', 31: 'xxxxx'
        }
dic6 = {0: 'ooooo', 1: 'oooox', 2: 'oooxo', 3: 'oooxx', 4: 'ooxoo', 5: 'ooxox', 6: 'ooxxo', 7: 'ooxxx',
        8: 'oxooo', 9: 'oxoox', 10: 'oxoxo', 11: 'oxoxx', 12: 'oxxoo', 13: 'oxxox', 14: 'oxxxo', 15: 'oxxxx',
        16: 'xoooo', 17: 'xooox', 18: 'xooxo', 19: 'xooxx', 20: 'xoxoo', 21: 'xoxox', 22: 'xoxxo', 23: 'xoxxx',
        24: 'xxooo', 25: 'xxoox', 26: 'xxoxo', 27: 'xxoxx', 28: 'xxxoo', 29: 'xxxox', 30: 'xxxxo', 31: 'xxxxx',
        32: 'ooooo', 33: 'oooox', 34: 'oooxo', 35: 'oooxx', 36: 'ooxoo', 37: 'ooxox', 38: 'ooxxo', 39: 'ooxxx',
        40: 'oxooo', 41: 'oxoox', 42: 'oxoxo', 43: 'oxoxx', 44: 'oxxoo', 45: 'oxxox', 46: 'oxxxo', 47: 'oxxxx',
        48: 'xoooo', 49: 'xooox', 50: 'xooxo', 51: 'xooxx', 52: 'xoxoo', 53: 'xoxox', 54: 'xoxxo', 55: 'xoxxx',
        56: 'xxooo', 57: 'xxoox', 58: 'xxoxo', 59: 'xxoxx', 60: 'xxxoo', 61: 'xxxox', 62: 'xxxxo', 63: 'xxxxx'
        }
dicX = []
dicX.append(dic1)
dicX.append(dic2)
dicX.append(dic3)
print len(dicX[2])
dicX.append(dic4)
dicX.append(dic5)
print dicX[3][2]
dicX.append(dic6)
