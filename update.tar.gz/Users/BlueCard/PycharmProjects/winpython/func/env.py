import os, json
import crypto
print os.environ
dic = {1:100}
jstr = json.dumps(dic)
print jstr
tp = type(jstr)
print tp
key1 = "hsylgwk-2012aaaa"
instr = "1234567890"
